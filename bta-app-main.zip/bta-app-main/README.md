# Mike Rhodes - Build the Agent - Quick Template v1

This is a template project for builders to create applications with AI.

## Getting started
Use cursor composer to create whatever you can think of!

## Technologies used
This doesn't really matter, but is useful for the AI to understand more about this project. We are using the following technologies
- React with Next.js 15 App Router
- TailwindCSS for design
- A google sheet deployed as a web app for the data storage
- A google script to power data fetching 

